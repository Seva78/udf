﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(SpriteRenderer))]
public class Sides : MonoBehaviour
{
    SpriteRenderer rend;
    public void Start()
    {
        rend = GetComponent<SpriteRenderer>();
        Texture2D tex = rend.sprite.texture;
        for (int x = 0; x < tex.width; x++) {
            for (int y = 0; y < tex.height; y++) {
                //tex.SetPixel(x, y, Color.blue);
            }
        }
        tex.Apply();
    }


    public void Update()
    {
                

        if (transform.position.y > 2005)
        {
            Destroy(gameObject);
        }
    }
}
